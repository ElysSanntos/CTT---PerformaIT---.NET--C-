﻿using System;
using System.Collections.Generic;
using System.Text;


namespace Xpto
{
    public class Program
    {
        public static string NomeCliente { get;  set; }

        static void Main(string[] args)
        {
            Cliente cliente = new Cliente();
            cliente.CodCliente = 01;
            cliente.NomeCliente = "Maria Jose";
            cliente.TelefoneCliente = "1234-1234";


           Console.WriteLine("Olá " + NomeCliente + "Vamos agendar um horario? \r\n"); //Não pega o nome da cliente//

            //Criar metodo sim/não para continuar


            Console.WriteLine("Escolha :  [1] 15:00 || [2] 16:00 || [3] 17:30");
            Cliente horaAgenda = new Cliente();
            cliente.AgendaHorario = int.Parse(Console.ReadLine());
            switch (cliente.AgendaHorario)
            {

                case 1:
                    '1';
                    Console.WriteLine("O horario Disponivel");
                    break;

                case 2:
                    '2';
                    Console.WriteLine("O horario Disponivel");
                    break;

                case 3:
                    '3';
                    Console.WriteLine("O horario Disponivel");
                    break;

                default:
                    Console.WriteLine("Horario Indisponivel ");
                    break;

            }

        }

      
         
    }
}
