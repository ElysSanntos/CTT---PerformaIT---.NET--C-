﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xpto
{
    //Criando as propriedades de Cliente
    public class Cliente
    {
        public int CodCliente { get; set; }
        public string NomeCliente { get; set; }
        public string TelefoneCliente { get; set; }

        public int AgendaHorario { get; set; }
    }

   // public Cliente() { }

}
