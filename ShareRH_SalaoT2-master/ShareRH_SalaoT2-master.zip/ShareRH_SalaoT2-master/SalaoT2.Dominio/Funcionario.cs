﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalaoT2.Dominio
{
    class Funcionario
    {
    }
}
